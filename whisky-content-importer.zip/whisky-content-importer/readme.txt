=== Whisky Content Importer ===
Contributors: whisky-journal
Requires at least: 6.0
Tested up to: 6.6
License: GPLv2 or later

Imports posts of type `whisky` from `whiskies.csv` or `whiskies.json` placed in `wp-content/uploads/whisky-import/`.
Fields: title, slug, description, region, classification, abv, age.
Admin: Tools → Імпорт віскі
