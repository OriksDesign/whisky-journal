<?php
/**
 * Plugin Name: Whisky Content Importer
 * Description: Імпорт записів типу "whisky" з CSV/JSON у папці wp-content/uploads/whisky-import. Підтримує поля: title, slug, description, region, classification, abv, age.
 * Version: 1.0.0
 * Author: Whisky Journal
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class WJ_Whisky_Content_Importer {

    const UPLOAD_SUBDIR = 'whisky-import';
    const MENU_SLUG = 'wj-whisky-import';

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'register_page' ] );
    }

    public function register_page() {
        add_management_page(
            __('Імпорт віскі', 'wj'),
            __('Імпорт віскі', 'wj'),
            'manage_options',
            self::MENU_SLUG,
            [ $this, 'render_page' ]
        );
    }

    protected function get_upload_dir() {
        $up = wp_upload_dir();
        return trailingslashit( $up['basedir'] ) . self::UPLOAD_SUBDIR;
    }

    protected function get_files() {
        $dir = $this->get_upload_dir();
        if ( ! is_dir( $dir ) ) return [];
        $files = [];
        foreach ( glob( trailingslashit($dir) . 'whiskies.*' ) as $f ) {
            $files[] = $f;
        }
        return $files;
    }

    public function render_page() {
        if ( isset($_POST['wj_run_import']) && check_admin_referer('wj_whisky_import') ) {
            $result = $this->run_import();
            echo '<div class="notice notice-success"><p>' . esc_html( $result ) . '</p></div>';
        }

        $files = $this->get_files();
        $dir = esc_html( $this->get_upload_dir() );
        echo '<div class="wrap"><h1>' . esc_html__('Імпорт віскі', 'wj') . '</h1>';
        echo '<p>' . sprintf( esc_html__('Покладіть файли %1$s або %2$s у папку: %3$s', 'wj'),
                '<code>whiskies.csv</code>', '<code>whiskies.json</code>', '<code>'.$dir.'</code>' ) . '</p>';
        if ( empty($files) ) {
            echo '<p><em>' . esc_html__('Файлів не знайдено.', 'wj') . '</em></p>';
        } else {
            echo '<p>' . esc_html__('Знайдено:', 'wj') . '</p><ul>';
            foreach ( $files as $f ) echo '<li><code>'. esc_html(basename($f)) .'</code></li>';
            echo '</ul>';
        }
        echo '<form method="post">';
        wp_nonce_field('wj_whisky_import');
        submit_button( __('Запустити імпорт', 'wj'), 'primary', 'wj_run_import' );
        echo '</form></div>';
    }

    protected function row_to_postarr( $row ) {
        $title = isset($row['title']) ? $row['title'] : '';
        $slug  = isset($row['slug']) ? sanitize_title($row['slug']) : sanitize_title($title);
        $content = isset($row['description']) ? $row['description'] : '';

        return [
            'post_type'   => 'whisky',
            'post_status' => 'publish',
            'post_title'  => $title,
            'post_name'   => $slug,
            'post_content'=> $content,
        ];
    }

    protected function ensure_term( $slug, $taxonomy, $name_fallback = '' ) {
        if ( empty($slug) ) return 0;
        $term = get_term_by('slug', $slug, $taxonomy );
        if ( $term && ! is_wp_error($term) ) return (int)$term->term_id;
        $res = wp_insert_term( $name_fallback ?: $slug, $taxonomy, [ 'slug' => $slug ] );
        if ( is_wp_error($res) ) return 0;
        return (int)$res['term_id'];
    }

    protected function handle_row( $row ) {
        $postarr = $this->row_to_postarr( $row );
        // Чи існує вже по slug?
        $existing = get_page_by_path( $postarr['post_name'], OBJECT, 'whisky' );
        if ( $existing ) {
            $postarr['ID'] = $existing->ID;
            $post_id = wp_update_post( $postarr, true );
        } else {
            $post_id = wp_insert_post( $postarr, true );
        }
        if ( is_wp_error($post_id) || ! $post_id ) return 0;

        // Таксономії
        $region = isset($row['region']) ? sanitize_title($row['region']) : '';
        $class  = isset($row['classification']) ? sanitize_title($row['classification']) : '';
        if ( $region ) {
            $term_id = $this->ensure_term( $region, 'region' );
            if ( $term_id ) wp_set_object_terms( $post_id, [$region], 'region', false );
        }
        if ( $class ) {
            $term_id = $this->ensure_term( $class, 'classification' );
            if ( $term_id ) wp_set_object_terms( $post_id, [$class], 'classification', false );
        }

        // Мета
        if ( isset($row['abv']) ) {
            update_post_meta( $post_id, 'abv', floatval( $row['abv'] ) );
        }
        if ( isset($row['age']) ) {
            update_post_meta( $post_id, 'age', is_numeric($row['age']) ? intval($row['age']) : sanitize_text_field($row['age']) );
        }
        return $post_id;
    }

    protected function read_csv( $file ) {
        $rows = [];
        if ( ($h = fopen($file, 'r')) ) {
            $headers = fgetcsv($h);
            if ( $headers ) {
                while ( ($data = fgetcsv($h)) ) {
                    $row = [];
                    foreach ( $headers as $i => $key ) {
                        $row[ trim($key) ] = isset($data[$i]) ? $data[$i] : '';
                    }
                    $rows[] = $row;
                }
            }
            fclose($h);
        }
        return $rows;
    }

    protected function read_json( $file ) {
        $data = json_decode( file_get_contents($file), true );
        return is_array($data) ? $data : [];
    }

    public function run_import() {
        $dir = $this->get_upload_dir();
        if ( ! is_dir($dir) ) return __('Папку не знайдено: ', 'wj') . $dir;

        $csv  = trailingslashit($dir) . 'whiskies.csv';
        $json = trailingslashit($dir) . 'whiskies.json';

        $rows = [];
        if ( file_exists($csv) ) {
            $rows = $this->read_csv( $csv );
        } elseif ( file_exists($json) ) {
            $rows = $this->read_json( $json );
        } else {
            return __('Не знайдено файлів whiskies.csv або whiskies.json', 'wj');
        }

        $count = 0;
        foreach ( $rows as $row ) {
            $id = $this->handle_row( $row );
            if ( $id ) $count++;
        }
        return sprintf( __('Імпортовано записів: %d', 'wj'), $count );
    }
}

new WJ_Whisky_Content_Importer();
