<?php
/**
 * Plugin Name: Whisky Classification Importer
 * Description: Імпорт термінів таксономій з CSV/JSON (зроблено для таксономії "classification"). Сторінка: Інструменти → Імпорт класифікацій.
 * Version: 1.0.0
 * Author: Whisky Journal
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Whisky_Classification_Importer {
    const PAGE_SLUG = 'wj_import_classifications';
    const DEFAULT_TAX = 'classification';
    const STORAGE_DIR = 'whisky-import'; // inside wp-content/uploads/

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'register_menu' ] );
        add_action( 'admin_init', [ $this, 'maybe_handle_upload' ] );
    }

    public function register_menu() {
        add_management_page(
            __('Імпорт класифікацій', 'wj'),
            __('Імпорт класифікацій', 'wj'),
            'manage_options',
            self::PAGE_SLUG,
            [ $this, 'render_page' ]
        );
    }

    protected function uploads_dir() {
        $upload = wp_upload_dir();
        $dir = trailingslashit( $upload['basedir'] ) . self::STORAGE_DIR;
        if ( ! file_exists( $dir ) ) {
            wp_mkdir_p( $dir );
        }
        return $dir;
    }

    protected function uploads_url() {
        $upload = wp_upload_dir();
        return trailingslashit( $upload['baseurl'] ) . self::STORAGE_DIR . '/';
    }

    public function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;

        $existing_files = glob( trailingslashit( $this->uploads_dir() ) . '*.{csv,json}', GLOB_BRACE );
        ?>
        <div class="wrap">
            <h1><?php _e('Імпорт класифікацій (CSV/JSON)', 'wj'); ?></h1>

            <?php if ( ! taxonomy_exists( self::DEFAULT_TAX ) ) : ?>
                <div class="notice notice-warning"><p>
                    <?php printf(
                        wp_kses_post( 'Увага: таксономія <code>%s</code> не зареєстрована. Імпорт можливий лише коли вона існує.', ['code' => []] ),
                        esc_html( self::DEFAULT_TAX )
                    ); ?>
                </p></div>
            <?php endif; ?>

            <h2><?php _e('1) Завантажити файл', 'wj'); ?></h2>
            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field( 'wj_import_upload', 'wj_import_nonce' ); ?>
                <input type="file" name="wj_import_file" accept=".csv,.json" required />
                <p><button type="submit" name="wj_import_action" value="upload" class="button button-primary"><?php _e('Імпортувати', 'wj'); ?></button></p>
                <p class="description"><?php _e('Очікувані колонки: name, slug, description, taxonomy (необов’язково), parent (необов’язково).', 'wj'); ?></p>
            </form>

            <h2><?php _e('2) Або вибрати з папки /uploads/whisky-import', 'wj'); ?></h2>
            <form method="post">
                <?php wp_nonce_field( 'wj_import_pick', 'wj_import_pick_nonce' ); ?>
                <select name="wj_pick_path">
                    <?php
                    if ( $existing_files ) {
                        foreach ( $existing_files as $path ) {
                            $rel = basename( $path );
                            printf( '<option value="%s">%s</option>', esc_attr( $rel ), esc_html( $rel ) );
                        }
                    } else {
                        echo '<option value="">' . esc_html__( 'Файлів не знайдено', 'wj' ) . '</option>';
                    }
                    ?>
                </select>
                <button type="submit" name="wj_import_action" value="pick" class="button"><?php _e('Імпортувати обраний файл', 'wj'); ?></button>
                <?php if ( $existing_files ) : ?>
                    <p class="description"><?php echo esc_html( $this->uploads_dir() ); ?></p>
                <?php endif; ?>
            </form>

            <hr/>
            <p><strong><?php _e('Підказка формату CSV:', 'wj'); ?></strong></p>
            <pre>name,slug,description,taxonomy,parent
Single Malt,single-malt,"Віскі з однієї дистилерії...",classification,</pre>
        </div>
        <?php
    }

    public function maybe_handle_upload() {
        if ( ! current_user_can( 'manage_options' ) ) return;

        // Upload new file
        if ( isset($_POST['wj_import_action']) && $_POST['wj_import_action'] === 'upload' ) {
            check_admin_referer( 'wj_import_upload', 'wj_import_nonce' );
            if ( ! isset($_FILES['wj_import_file']) || empty($_FILES['wj_import_file']['name']) ) return;

            require_once ABSPATH . 'wp-admin/includes/file.php';
            $overrides = [ 'test_form' => false, 'mimes' => [ 'csv' => 'text/csv', 'json' => 'application/json' ] ];
            $movefile = wp_handle_upload( $_FILES['wj_import_file'], $overrides );
            if ( isset($movefile['error']) ) {
                add_action( 'admin_notices', function() use ( $movefile ) {
                    echo '<div class="notice notice-error"><p>' . esc_html( $movefile['error'] ) . '</p></div>';
                });
                return;
            }
            // move into our storage dir
            $target_dir = $this->uploads_dir();
            $target = trailingslashit( $target_dir ) . basename( $movefile['file'] );
            @rename( $movefile['file'], $target );

            $this->import_file( $target );
        }

        // Pick existing file
        if ( isset($_POST['wj_import_action']) && $_POST['wj_import_action'] === 'pick' ) {
            check_admin_referer( 'wj_import_pick', 'wj_import_pick_nonce' );
            $rel = isset($_POST['wj_pick_path']) ? sanitize_file_name( wp_unslash($_POST['wj_pick_path']) ) : '';
            if ( ! $rel ) return;
            $path = trailingslashit( $this->uploads_dir() ) . $rel;
            if ( file_exists( $path ) ) {
                $this->import_file( $path );
            }
        }
    }

    protected function import_file( $path ) {
        $ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
        $rows = [];

        if ( $ext === 'json' ) {
            $content = file_get_contents( $path );
            $data = json_decode( $content, true );
            if ( is_array( $data ) ) $rows = $data;
        } elseif ( $ext === 'csv' ) {
            if ( ( $handle = fopen( $path, 'r' ) ) !== false ) {
                $header = fgetcsv( $handle, 0, ',' );
                if ( $header ) {
                    $header = array_map( 'trim', $header );
                    while ( ( $r = fgetcsv( $handle, 0, ',' ) ) !== false ) {
                        $row = [];
                        foreach ( $header as $i => $key ) {
                            $row[ $key ] = isset( $r[$i] ) ? $r[$i] : '';
                        }
                        $rows[] = $row;
                    }
                }
                fclose( $handle );
            }
        }

        $result = $this->import_rows( $rows );

        add_action( 'admin_notices', function() use ( $result, $path ) {
            printf(
                '<div class="notice notice-success"><p>%s<br/>%s</p></div>',
                esc_html( sprintf( 'Імпортовано: створено %d, оновлено %d, пропущено %d.', $result['created'], $result['updated'], $result['skipped'] ) ),
                esc_html( 'Файл: ' . basename( $path ) )
            );
        } );
    }

    protected function import_rows( $rows ) {
        $created = $updated = $skipped = 0;

        foreach ( (array)$rows as $r ) {
            $name  = isset($r['name']) ? trim( $r['name'] ) : '';
            $slug  = isset($r['slug']) ? sanitize_title( $r['slug'] ) : '';
            $desc  = isset($r['description']) ? wp_kses_post( $r['description'] ) : '';
            $tax   = isset($r['taxonomy']) && $r['taxonomy'] ? sanitize_key( $r['taxonomy'] ) : self::DEFAULT_TAX;
            $parent_label = isset($r['parent']) ? trim( $r['parent'] ) : '';

            if ( ! $name || ! taxonomy_exists( $tax ) ) {
                $skipped++; continue;
            }

            $parent = 0;
            if ( $parent_label ) {
                $parent_term = get_term_by( 'slug', sanitize_title( $parent_label ), $tax );
                if ( ! $parent_term ) $parent_term = get_term_by( 'name', $parent_label, $tax );
                if ( $parent_term && ! is_wp_error( $parent_term ) ) $parent = (int) $parent_term->term_id;
            }

            $exists = term_exists( $slug ? $slug : $name, $tax );
            if ( $exists && is_array( $exists ) ) {
                // update
                wp_update_term( (int)$exists['term_id'], $tax, [
                    'name'        => $name,
                    'slug'        => $slug ?: null,
                    'description' => $desc,
                    'parent'      => $parent,
                ]);
                $updated++;
            } else {
                $res = wp_insert_term( $name, $tax, [
                    'slug'        => $slug ?: null,
                    'description' => $desc,
                    'parent'      => $parent,
                ]);
                if ( ! is_wp_error( $res ) ) $created++; else $skipped++;
            }
        }

        return compact( 'created', 'updated', 'skipped' );
    }
}

new Whisky_Classification_Importer();
